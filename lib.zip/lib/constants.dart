import 'package:flutter/material.dart';

Color kPrimary = Color(0xFF0E4749);
Color kSecondary = Color(0xFF002626);
Color kTextPrimary = Color(0xFFEFE7DA);
Color kTextSecondary = Color(0xFFE55812);
