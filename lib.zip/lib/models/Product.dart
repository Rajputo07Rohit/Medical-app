class Product {
  String name;
  String img;
  String description;
  int price;
  Product(this.name, this.description, this.img, this.price);
}
